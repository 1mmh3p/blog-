
-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `baslik` varchar(255) NOT NULL,
  `icerik` text NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `tarih` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `kullanici_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `blog`
--

INSERT INTO `blog` (`id`, `baslik`, `icerik`, `kategori`, `tarih`, `kullanici_id`) VALUES
(4, 'Kişisel Yazı: Başlık: Yolculuk ve Keşif', 'Bir Yola Çıkmak: İçsel Keşif\r\n\r\nBugün, sabah erkenden evden çıkarken yanıma aldığım tek şey, eski bir defter ve bir kalemdi. Gerçekten ne yapacağımı bilmiyordum, ama o anda hissettiğim şey yalnızca bir adım atma arzusuydu. Yaşamın karmaşasında kaybolmuş gibi hissediyordum. Her şey bir araya geldiğinde, insan kendini kaybetmiş hissediyor; aile, iş, sosyal sorumluluklar arasında dengeyi bulmak zorlaşıyor. Bu yüzden yola çıkma kararı aldım.\r\n\r\nYolda ilerlerken, en basit şeylerin ne kadar değerli olduğunu fark ettim. Bir çiçek, bir kuş, hatta güneşin yavaşça batışı bile içimi ısıtıyordu. Bu yolculuk sadece fiziksel bir hareket değildi; aynı zamanda ruhsal bir yenilenme süreciydi. Birçok şeyi sorguladım, birçok sorunun cevabını kendi içimde buldum.\r\n\r\nBu yazı, sadece yola çıktığımda hissettiklerimi değil, aynı zamanda içsel huzurumu bulmak için geçirdiğim zamanı anlatıyor. Yola çıktıkça, her adımda daha da fazla farkına vardım ki, hayatın anlamı sadece varmakta değil, yolculukta.', '', '2025-03-23 18:45:19', NULL),
(5, 'Seyahat Notları: Başlık: Gizli Ada: Keşfedilen Cennet', 'Bir grup maceracı, okyanuslarda kaybolmuş bir adayı keşfetti. Ada, doğallığını koruyarak bembeyaz kumsallar, tropikal ormanlar ve bilinmeyen hayvan türleriyle dikkat çekiyor.', '', '2025-03-23 18:46:43', NULL),
(6, 'Kitap Önerisi: Başlık: Zamanın Kıyısında', 'Bir bilim kurgu romanı, zaman yolculuğu yaparak geçmişi değiştirmeye çalışan bir adamın hikayesini anlatıyor. Hem düşündürücü hem de görsel açıdan etkileyici bir anlatım sunuyor.', '', '2025-03-23 18:47:09', NULL),
(7, 'Teknoloji: Başlık: Yapay Zeka ve İnsan Beyni', 'Yapay zeka teknolojisi, son yıllarda insan beynine daha yakın bir model haline gelmeye başladı. Sinirsel ağlar üzerinden yapılan çalışmalar, beyin ve yapay zekanın etkileşimini anlamada önemli bir adım atılmasına olanak sağlıyor. Bu yeni teknoloji, beyin fonksiyonlarını daha doğru simüle ederek, nörolojik hastalıkların tedavisinde devrim yaratabilir. Yapay zeka, sadece fiziksel hastalıkları değil, aynı zamanda ruhsal ve zihinsel bozuklukları da tedavi etmek için kullanılabilecek bir araç haline gelebilir.', '', '2025-03-23 18:48:15', NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `galeri`
--

CREATE TABLE `galeri` (
  `id` int(11) NOT NULL,
  `resim_yolu` varchar(255) NOT NULL,
  `aciklama` text,
  `kategori` varchar(50) NOT NULL,
  `tarih` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `galeri`
--

INSERT INTO `galeri` (`id`, `resim_yolu`, `aciklama`, `kategori`, `tarih`) VALUES
(2, './resim/01.jpg', 'Hobilerimle İlgili Görseller', 'Hobilerimle İlgili Görseller', '2025-03-23 23:32:33'),
(3, './resim/01.webp', 'Fotoğraflarım', 'Fotoğraflarım', '2025-03-23 23:32:56'),
(4, 'https://picsum.photos/200', 'Yakinde Eklenecek Video ', 'Video & Multimedya İçerikleri', '2025-03-23 20:31:31');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `icerikler`
--

CREATE TABLE `icerikler` (
  `id` int(11) NOT NULL,
  `sayfa` varchar(50) NOT NULL,
  `baslik` varchar(255) NOT NULL,
  `icerik` text NOT NULL,
  `tarih` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE `kullanicilar` (
  `id` int(11) NOT NULL,
  `kullanici_adi` varchar(50) NOT NULL,
  `sifre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`id`, `kullanici_adi`, `sifre`) VALUES
(1, 'admin', '$2y$10$ZdWe0wbJcs1dpWJD05zrhuNx/KZlQWXyKNbgj8sz.JnFoeuGoMKVq');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_baslik` (`baslik`),
  ADD KEY `idx_kategori` (`kategori`),
  ADD KEY `fk_kullanici` (`kullanici_id`);

--
-- Tablo için indeksler `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `icerikler`
--
ALTER TABLE `icerikler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kullanicilar`
--
ALTER TABLE `kullanicilar`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Tablo için AUTO_INCREMENT değeri `galeri`
--
ALTER TABLE `galeri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `icerikler`
--
ALTER TABLE `icerikler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `kullanicilar`
--
ALTER TABLE `kullanicilar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

