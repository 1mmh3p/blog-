document.addEventListener('DOMContentLoaded', function() {
    console.log('Site yüklendi!');
});



function toggleSubMenu(menuId) {
    var menu = document.getElementById(menuId);
    
    // Toggle the visibility of the clicked menu
    if (menu.style.display === 'block') {
        menu.style.display = 'none';
    } else {
        menu.style.display = 'block';
    }
    
    // Close other menus
    var allMenus = document.querySelectorAll('.submenu');
    allMenus.forEach(function (m) {
        if (m.id !== menuId) {
            m.style.display = 'none';
        }
    });
}


function toggleMenu() {
    document.querySelector('.menu').classList.toggle('active');
}


