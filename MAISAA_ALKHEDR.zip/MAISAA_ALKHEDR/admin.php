<?php
session_start();
ob_start();

// Veritabanı bağlantısı
$db = new mysqli('localhost', 'root', 'admin#123', 'maissa');

if ($db->connect_error) {
    die("<div class='alert alert-danger'>Veritabanı bağlantı hatası: " . $db->connect_error . "</div>");
}

// Admin bilgileri
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', '1234');
$hashed_admin_pass = password_hash(ADMIN_PASS, PASSWORD_BCRYPT);

// Çıkış işlemi
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit();
}

// CSS Stilleri (inline olarak ekleniyor)
$styles = <<<CSS
<style>
:root {
    --primary-color: #3498db;
    --secondary-color: #2ecc71;
    --danger-color: #e74c3c;
    --dark-color: #2c3e50;
    --light-color: #ecf0f1;
    --gray-color: #95a5a6;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
    background-color: #f5f7fa;
    color: #333;
    line-height: 1.6;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.header {
    background-color: var(--dark-color);
    color: white;
    padding: 15px 0;
    margin-bottom: 30px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo {
    font-size: 24px;
    font-weight: bold;
}

.nav {
    display: flex;
    gap: 20px;
}

.nav a {
    color: white;
    text-decoration: none;
    padding: 5px 10px;
    border-radius: 4px;
    transition: background-color 0.3s;
}

.nav a:hover {
    background-color: rgba(255,255,255,0.2);
}

.section {
    background-color: white;
    border-radius: 8px;
    padding: 25px;
    margin-bottom: 30px;
    box-shadow: 0 2px 15px rgba(0,0,0,0.05);
}

.section-title {
    color: var(--dark-color);
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid var(--light-color);
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: var(--dark-color);
}

.form-control {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 16px;
    transition: border-color 0.3s;
}

.form-control:focus {
    border-color: var(--primary-color);
    outline: none;
}

textarea.form-control {
    min-height: 150px;
    resize: vertical;
}

.btn {
    display: inline-block;
    padding: 12px 24px;
    background-color: var(--primary-color);
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    font-weight: 600;
    transition: background-color 0.3s;
    text-decoration: none;
}

.btn:hover {
    background-color: #2980b9;
}

.btn-secondary {
    background-color: var(--secondary-color);
}

.btn-secondary:hover {
    background-color: #27ae60;
}

.btn-danger {
    background-color: var(--danger-color);
}

.btn-danger:hover {
    background-color: #c0392b;
}

.btn-sm {
    padding: 8px 16px;
    font-size: 14px;
}

.alert {
    padding: 15px;
    border-radius: 4px;
    margin-bottom: 20px;
}

.alert-danger {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.table th, .table td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.table th {
    background-color: var(--light-color);
    color: var(--dark-color);
    font-weight: 600;
}

.table tr:hover {
    background-color: rgba(0,0,0,0.02);
}

.card {
    background-color: white;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}

.card-title {
    font-size: 18px;
    margin-bottom: 15px;
    color: var(--dark-color);
}

.login-container {
    max-width: 400px;
    margin: 100px auto;
    background-color: white;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    text-align: center;
}

.login-container h2 {
    margin-bottom: 20px;
    color: var(--dark-color);
}

.login-container input[type="text"],
.login-container input[type="password"] {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.login-container input[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: var(--primary-color);
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s;
}

.login-container input[type="submit"]:hover {
    background-color: #2980b9;
}

.home-link {
    display: inline-block;
    margin-bottom: 20px;
    color: var(--primary-color);
    text-decoration: none;
}

.home-link:hover {
    text-decoration: underline;
}

.grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.grid-item {
    border: 1px solid #eee;
    border-radius: 8px;
    overflow: hidden;
    transition: transform 0.3s, box-shadow 0.3s;
}

.grid-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

.grid-img {
    width: 100%;
    height: 180px;
    object-fit: cover;
}

.grid-body {
    padding: 15px;
}

.grid-title {
    font-size: 16px;
    margin-bottom: 10px;
}

.grid-text {
    color: var(--gray-color);
    font-size: 14px;
    margin-bottom: 10px;
}

.action-buttons {
    display: flex;
    gap: 10px;
}

@media (max-width: 768px) {
    .header-content {
        flex-direction: column;
        gap: 15px;
    }
    
    .nav {
        width: 100%;
        justify-content: center;
    }
    
    .grid {
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    }
}
</style>
CSS;

// Giriş kontrolü
if (!isset($_SESSION['giris_yapildi'])) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $kullanici_adi = $_POST['kullanici_adi'];
        $sifre = $_POST['sifre'];
        
        if ($kullanici_adi === ADMIN_USER && password_verify($sifre, $hashed_admin_pass)) {
            $_SESSION['giris_yapildi'] = true;
            header("Location: admin.php");
            exit();
        } else {
            $error_message = "Hatalı kullanıcı adı veya şifre!";
        }
    }
    
    echo '<!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Giriş | Yönetim Paneli</title>
        ' . $styles . '
    </head>
    <body>
        <div class="login-container">
            <h2>Yönetim Paneli Giriş</h2>
            ' . (isset($error_message) ? '<div class="alert alert-danger">' . $error_message . '</div>' : '') . '
            <form method="post">
                <input type="text" name="kullanici_adi" placeholder="Kullanıcı Adı" required>
                <input type="password" name="sifre" placeholder="Şifre" required>
                <input type="submit" value="Giriş Yap" class="btn">
            </form>
            <a href="./index.php" class="home-link">← Site Ana Sayfasına Dön</a>
        </div>
    </body>
    </html>';
    exit();
}

// Blog Yönetimi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['icerik_ekle'])) {
        $baslik = $db->real_escape_string($_POST['baslik']);
        $icerik = $db->real_escape_string($_POST['icerik']);
        $kategori = $db->real_escape_string($_POST['kategori'] ?? 'genel');
        
        $stmt = $db->prepare("INSERT INTO blog (baslik, icerik, kategori) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $baslik, $icerik, $kategori);
        if ($stmt->execute()) {
            $success_message = "İçerik başarıyla eklendi!";
        } else {
            $error_message = "İçerik eklenirken hata oluştu: " . $stmt->error;
        }
    }
    
    if (isset($_POST['icerik_duzenle_submit'])) {
        $id = (int)$_POST['icerik_id'];
        $baslik = $db->real_escape_string($_POST['baslik']);
        $icerik = $db->real_escape_string($_POST['icerik']);
        $kategori = $db->real_escape_string($_POST['kategori'] ?? 'genel');
        
        $stmt = $db->prepare("UPDATE blog SET baslik=?, icerik=?, kategori=? WHERE id=?");
        $stmt->bind_param("sssi", $baslik, $icerik, $kategori, $id);
        if ($stmt->execute()) {
            $success_message = "İçerik başarıyla güncellendi!";
        } else {
            $error_message = "İçerik güncellenirken hata oluştu: " . $stmt->error;
        }
    }
    
    if (isset($_POST['resim_ekle'])) {
        $resim_yolu = $db->real_escape_string($_POST['resim_yolu']);
        $aciklama = $db->real_escape_string($_POST['aciklama']);
        $kategori = $db->real_escape_string($_POST['kategori']);
        
        $stmt = $db->prepare("INSERT INTO galeri (resim_yolu, aciklama, kategori) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $resim_yolu, $aciklama, $kategori);
        if ($stmt->execute()) {
            $success_message = "Resim başarıyla eklendi!";
        } else {
            $error_message = "Resim eklenirken hata oluştu: " . $stmt->error;
        }
    }
    
    if (isset($_POST['resim_duzenle_submit'])) {
        $id = (int)$_POST['resim_id'];
        $resim_yolu = $db->real_escape_string($_POST['resim_yolu']);
        $aciklama = $db->real_escape_string($_POST['aciklama']);
        $kategori = $db->real_escape_string($_POST['kategori']);
        
        $stmt = $db->prepare("UPDATE galeri SET resim_yolu=?, aciklama=?, kategori=? WHERE id=?");
        $stmt->bind_param("sssi", $resim_yolu, $aciklama, $kategori, $id);
        if ($stmt->execute()) {
            $success_message = "Resim başarıyla güncellendi!";
        } else {
            $error_message = "Resim güncellenirken hata oluştu: " . $stmt->error;
        }
    }
    
    if (isset($_POST['kullanici_ekle'])) {
        $kullanici_adi = $db->real_escape_string($_POST['kullanici_adi']);
        $sifre = password_hash($_POST['sifre'], PASSWORD_BCRYPT);
        
        $stmt = $db->prepare("INSERT INTO kullanicilar (kullanici_adi, sifre) VALUES (?, ?)");
        $stmt->bind_param("ss", $kullanici_adi, $sifre);
        if ($stmt->execute()) {
            $success_message = "Kullanıcı başarıyla eklendi!";
        } else {
            $error_message = "Kullanıcı eklenirken hata oluştu: " . $stmt->error;
        }
    }
    
    if (isset($_POST['kullanici_duzenle_submit'])) {
        $id = (int)$_POST['kullanici_id'];
        $kullanici_adi = $db->real_escape_string($_POST['kullanici_adi']);
        $sifre = password_hash($_POST['sifre'], PASSWORD_BCRYPT);
        
        $stmt = $db->prepare("UPDATE kullanicilar SET kullanici_adi=?, sifre=? WHERE id=?");
        $stmt->bind_param("ssi", $kullanici_adi, $sifre, $id);
        if ($stmt->execute()) {
            $success_message = "Kullanıcı başarıyla güncellendi!";
        } else {
            $error_message = "Kullanıcı güncellenirken hata oluştu: " . $stmt->error;
        }
    }
    
    // Başarılı işlem sonrası yönlendirme
    if (isset($success_message)) {
        $_SESSION['success_message'] = $success_message;
        header("Location: admin.php");
        exit();
    }
}

// Silme işlemleri
if (isset($_GET['icerik_sil'])) {
    $id = (int)$_GET['icerik_sil'];
    if ($db->query("DELETE FROM blog WHERE id=$id")) {
        $_SESSION['success_message'] = "İçerik başarıyla silindi!";
    } else {
        $_SESSION['error_message'] = "İçerik silinirken hata oluştu: " . $db->error;
    }
    header("Location: admin.php");
    exit();
}

if (isset($_GET['resim_sil'])) {
    $id = (int)$_GET['resim_sil'];
    if ($db->query("DELETE FROM galeri WHERE id=$id")) {
        $_SESSION['success_message'] = "Resim başarıyla silindi!";
    } else {
        $_SESSION['error_message'] = "Resim silinirken hata oluştu: " . $db->error;
    }
    header("Location: admin.php");
    exit();
}

if (isset($_GET['kullanici_sil'])) {
    $id = (int)$_GET['kullanici_sil'];
    if ($db->query("DELETE FROM kullanicilar WHERE id=$id")) {
        $_SESSION['success_message'] = "Kullanıcı başarıyla silindi!";
    } else {
        $_SESSION['error_message'] = "Kullanıcı silinirken hata oluştu: " . $db->error;
    }
    header("Location: admin.php");
    exit();
}

// Düzenleme modları
if (isset($_GET['icerik_duzenle'])) {
    $id = (int)$_GET['icerik_duzenle'];
    $result = $db->query("SELECT * FROM blog WHERE id=$id");
    $icerik_row = $result->fetch_assoc();
}

if (isset($_GET['resim_duzenle'])) {
    $id = (int)$_GET['resim_duzenle'];
    $result = $db->query("SELECT * FROM galeri WHERE id=$id");
    $resim_row = $result->fetch_assoc();
}

if (isset($_GET['kullanici_duzenle'])) {
    $id = (int)$_GET['kullanici_duzenle'];
    $result = $db->query("SELECT * FROM kullanicilar WHERE id=$id");
    $kullanici_row = $result->fetch_assoc();
}

// Verileri çekme
$blog_icerikleri = $db->query("SELECT * FROM blog ORDER BY id DESC");
$galeri_icerikleri = $db->query("SELECT * FROM galeri ORDER BY id DESC");
$kullanicilar = $db->query("SELECT * FROM kullanicilar ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yönetim Paneli | Admin</title>
    <?= $styles ?>
</head>
<body>
    <header class="header">
        <div class="container header-content">
            <div class="logo">Yönetim Paneli</div>
            <nav class="nav">
                <a href="admin.php">Ana Sayfa</a>
                <a href="?logout=true">Çıkış Yap</a>
                <a href="./index.php">Siteye Git</a>
            </nav>
        </div>
    </header>

    <main class="container">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success_message'] ?></div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error_message'] ?></div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <!-- Blog Yönetimi -->
        <section class="section">
            <h2 class="section-title">Blog İçerik Yönetimi</h2>
            
            <form method="post" class="form">
                <div class="form-group">
                    <label for="baslik">Başlık</label>
                    <input type="text" id="baslik" name="baslik" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="kategori">Kategori</label>
                    <input type="text" id="kategori" name="kategori" class="form-control" value="genel">
                </div>
                
                <div class="form-group">
                    <label for="icerik">İçerik</label>
                    <textarea id="icerik" name="icerik" class="form-control" required></textarea>
                </div>
                
                <button type="submit" name="icerik_ekle" class="btn btn-secondary">İçerik Ekle</button>
            </form>
            
            <h3 style="margin-top: 30px;">Mevcut İçerikler</h3>
            <div class="grid">
                <?php while ($row = $blog_icerikleri->fetch_assoc()): ?>
                    <div class="card">
                        <h4 class="card-title"><?= htmlspecialchars($row['baslik']) ?></h4>
                        <p class="grid-text"><?= substr(htmlspecialchars($row['icerik']), 0, 100) ?>...</p>
                        <p><small>Kategori: <?= htmlspecialchars($row['kategori']) ?></small></p>
                        <div class="action-buttons">
                            <a href="?icerik_sil=<?= $row['id'] ?>" class="btn btn-danger btn-sm">Sil</a>
                            <a href="?icerik_duzenle=<?= $row['id'] ?>" class="btn btn-sm">Düzenle</a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </section>

        <?php if (isset($icerik_row)): ?>
            <section class="section">
                <h2 class="section-title">İçerik Düzenle</h2>
                
                <form method="post" class="form">
                    <input type="hidden" name="icerik_id" value="<?= $icerik_row['id'] ?>">
                    
                    <div class="form-group">
                        <label for="edit_baslik">Başlık</label>
                        <input type="text" id="edit_baslik" name="baslik" class="form-control" value="<?= htmlspecialchars($icerik_row['baslik']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_kategori">Kategori</label>
                        <input type="text" id="edit_kategori" name="kategori" class="form-control" value="<?= htmlspecialchars($icerik_row['kategori']) ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_icerik">İçerik</label>
                        <textarea id="edit_icerik" name="icerik" class="form-control" required><?= htmlspecialchars($icerik_row['icerik']) ?></textarea>
                    </div>
                    
                    <button type="submit" name="icerik_duzenle_submit" class="btn btn-secondary">Güncelle</button>
                    <a href="admin.php" class="btn">İptal</a>
                </form>
            </section>
        <?php endif; ?>

        <!-- Galeri Yönetimi -->
        <section class="section">
            <h2 class="section-title">Galeri Yönetimi</h2>
            
            <form method="post" class="form">
                <div class="form-group">
                    <label for="resim_yolu">Resim Yolu (URL)</label>
                    <input type="text" id="resim_yolu" name="resim_yolu" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="aciklama">Açıklama</label>
                    <textarea id="aciklama" name="aciklama" class="form-control"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="galeri_kategori">Kategori</label>
                    <input type="text" id="galeri_kategori" name="kategori" class="form-control" required>
                </div>
                
                <button type="submit" name="resim_ekle" class="btn btn-secondary">Resim Ekle</button>
            </form>
            
            <h3 style="margin-top: 30px;">Galeri İçerikleri</h3>
            <div class="grid">
                <?php while ($row = $galeri_icerikleri->fetch_assoc()): ?>
                    <div class="grid-item">
                        <img src="<?= htmlspecialchars($row['resim_yolu']) ?>" alt="<?= htmlspecialchars($row['aciklama']) ?>" class="grid-img">
                        <div class="grid-body">
                            <h4 class="grid-title"><?= htmlspecialchars($row['aciklama']) ?></h4>
                            <p class="grid-text">Kategori: <?= htmlspecialchars($row['kategori']) ?></p>
                            <div class="action-buttons">
                                <a href="?resim_sil=<?= $row['id'] ?>" class="btn btn-danger btn-sm">Sil</a>
                                <a href="?resim_duzenle=<?= $row['id'] ?>" class="btn btn-sm">Düzenle</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </section>

        <?php if (isset($resim_row)): ?>
            <section class="section">
                <h2 class="section-title">Resim Düzenle</h2>
                
                <form method="post" class="form">
                    <input type="hidden" name="resim_id" value="<?= $resim_row['id'] ?>">
                    
                    <div class="form-group">
                        <label for="edit_resim_yolu">Resim Yolu (URL)</label>
                        <input type="text" id="edit_resim_yolu" name="resim_yolu" class="form-control" value="<?= htmlspecialchars($resim_row['resim_yolu']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_aciklama">Açıklama</label>
                        <textarea id="edit_aciklama" name="aciklama" class="form-control"><?= htmlspecialchars($resim_row['aciklama']) ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_galeri_kategori">Kategori</label>
                        <input type="text" id="edit_galeri_kategori" name="kategori" class="form-control" value="<?= htmlspecialchars($resim_row['kategori']) ?>" required>
                    </div>
                    
                    <button type="submit" name="resim_duzenle_submit" class="btn btn-secondary">Güncelle</button>
                    <a href="admin.php" class="btn">İptal</a>
                </form>
            </section>
        <?php endif; ?>

        <!-- Kullanıcı Yönetimi -->
        <section class="section">
            <h2 class="section-title">Kullanıcı Yönetimi</h2>
            
            <form method="post" class="form">
                <div class="form-group">
                    <label for="kullanici_adi">Kullanıcı Adı</label>
                    <input type="text" id="kullanici_adi" name="kullanici_adi" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="kullanici_sifre">Şifre</label>
                    <input type="password" id="kullanici_sifre" name="sifre" class="form-control" required>
                </div>
                
                <button type="submit" name="kullanici_ekle" class="btn btn-secondary">Kullanıcı Ekle</button>
            </form>
            
            <h3 style="margin-top: 30px;">Kullanıcı Listesi</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Kullanıcı Adı</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $kullanicilar->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['kullanici_adi']) ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?kullanici_sil=<?= $row['id'] ?>" class="btn btn-danger btn-sm">Sil</a>
                                    <a href="?kullanici_duzenle=<?= $row['id'] ?>" class="btn btn-sm">Düzenle</a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </section>

        <?php if (isset($kullanici_row)): ?>
            <section class="section">
                <h2 class="section-title">Kullanıcı Düzenle</h2>
                
                <form method="post" class="form">
                    <input type="hidden" name="kullanici_id" value="<?= $kullanici_row['id'] ?>">
                    
                    <div class="form-group">
                        <label for="edit_kullanici_adi">Kullanıcı Adı</label>
                        <input type="text" id="edit_kullanici_adi" name="kullanici_adi" class="form-control" value="<?= htmlspecialchars($kullanici_row['kullanici_adi']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_kullanici_sifre">Yeni Şifre</label>
                        <input type="password" id="edit_kullanici_sifre" name="sifre" class="form-control" required>
                    </div>
                    
                    <button type="submit" name="kullanici_duzenle_submit" class="btn btn-secondary">Güncelle</button>
                    <a href="admin.php" class="btn">İptal</a>
                </form>
            </section>
        <?php endif; ?>
    </main>
</body>
</html>
<?php
$db->close();
ob_end_flush();
?>