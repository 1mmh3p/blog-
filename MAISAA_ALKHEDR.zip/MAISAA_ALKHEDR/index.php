<?php
$db = new mysqli('localhost', 'root', 'admin#123', 'maissa');

if ($db->connect_error) {
    die("Veritabanı bağlantı hatası: " . $db->connect_error);
}

// Rastgele 4 blog yazısı
$random_blog_posts = $db->query("SELECT * FROM blog ORDER BY RAND() LIMIT 4");

// Tüm blog yazıları
$blog_icerikleri = $db->query("SELECT * FROM blog");

// Galeri içerikleri
$galeri_icerikleri = $db->query("SELECT * FROM galeri");
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAISAA ALKHEDR | Profesyonel Kişisel Blog</title>
    <style>
        /* === GENEL STİLLER === */
        :root {
            --primary: #6C63FF;
            --secondary: #FF6584;
            --dark: #2D3748;
            --light: #F7FAFC;
            --accent: #4FD1C5;
            --gray: #A0AEC0;
            --success: #48BB78;
            --warning: #ED8936;
            --danger: #F56565;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light);
            color: var(--dark);
            line-height: 1.6;
        }
        
        a {
            text-decoration: none;
            color: inherit;
            transition: var(--transition);
        }
        
        img {
            max-width: 100%;
            height: auto;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: var(--primary);
            color: white;
            border-radius: 30px;
            font-weight: 600;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            text-align: center;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(108, 99, 255, 0.2);
        }
        
        .btn-secondary {
            background-color: var(--secondary);
        }
        
        .btn-outline {
            background-color: transparent;
            border: 2px solid var(--primary);
            color: var(--primary);
        }
        
        .section {
            padding: 80px 0;
        }
        
        .section-title {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
            color: var(--dark);
            position: relative;
            display: inline-block;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background-color: var(--primary);
            border-radius: 2px;
        }
        
        .section-subtitle {
            font-size: 1.2rem;
            color: var(--gray);
            margin-bottom: 3rem;
            max-width: 700px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: var(--transition);
            margin-bottom: 30px;
        }
        
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .card-img {
            height: 200px;
            overflow: hidden;
        }
        
        .card-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }
        
        .card:hover .card-img img {
            transform: scale(1.1);
        }
        
        .card-body {
            padding: 20px;
        }
        
        .card-title {
            font-size: 1.3rem;
            margin-bottom: 10px;
            color: var(--dark);
        }
        
        .card-text {
            color: var(--gray);
            margin-bottom: 15px;
        }
        
        .card-date {
            font-size: 0.9rem;
            color: var(--gray);
            display: flex;
            align-items: center;
        }
        
        .card-date i {
            margin-right: 5px;
            color: var(--primary);
        }
        
        /* === NAVBAR === */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background-color: white;
            box-shadow: var(--shadow);
            z-index: 1000;
            padding: 15px 0;
            transition: var(--transition);
        }
        
        .navbar.scrolled {
            padding: 10px 0;
            background-color: rgba(255, 255, 255, 0.95);
        }
        
        .navbar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary);
            display: flex;
            align-items: center;
        }
        
        .logo span {
            color: var(--secondary);
        }
        
        .nav-menu {
            display: flex;
            list-style: none;
        }
        
        .nav-item {
            margin-left: 30px;
            position: relative;
        }
        
        .nav-link {
            font-weight: 600;
            color: var(--dark);
            padding: 5px 0;
            position: relative;
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background-color: var(--primary);
            transition: var(--transition);
        }
        
        .nav-link:hover::after {
            width: 100%;
        }
        
        .nav-link.active {
            color: var(--primary);
        }
        
        .dropdown {
            position: relative;
        }
        
        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            background-color: white;
            box-shadow: var(--shadow);
            border-radius: 5px;
            padding: 10px 0;
            min-width: 200px;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 100;
        }
        
        .dropdown:hover .dropdown-menu {
            opacity: 1;
            visibility: visible;
        }
        
        .dropdown-item {
            display: block;
            padding: 8px 20px;
            color: var(--dark);
            transition: var(--transition);
        }
        
        .dropdown-item:hover {
            background-color: #f8f9fa;
            color: var(--primary);
        }
        
        .hamburger {
            display: none;
            cursor: pointer;
            width: 30px;
            height: 20px;
            flex-direction: column;
            justify-content: space-between;
        }
        
        .hamburger span {
            display: block;
            width: 100%;
            height: 3px;
            background-color: var(--dark);
            transition: var(--transition);
        }
        
        /* === HERO SECTION === */
        .hero {
            height: 100vh;
            background: linear-gradient(135deg, rgba(108, 99, 255, 0.8), rgba(255, 101, 132, 0.8)), url('https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80') no-repeat center center/cover;
            display: flex;
            align-items: center;
            color: white;
            text-align: center;
            padding-top: 80px;
        }
        
        .hero-content {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .hero-title {
            font-size: 3.5rem;
            margin-bottom: 20px;
            line-height: 1.2;
        }
        
        .hero-subtitle {
            font-size: 1.5rem;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        
        .hero-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        
        /* === ABOUT SECTION === */
        .about {
            background-color: white;
        }
        
        .about-content {
            display: flex;
            align-items: center;
            gap: 50px;
        }
        
        .about-img {
            flex: 1;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--shadow);
        }
        
        .about-text {
            flex: 1;
        }
        
        .about-text h3 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: var(--dark);
        }
        
        .about-text p {
            margin-bottom: 15px;
        }
        
        .skills {
            margin-top: 30px;
        }
        
        .skill-item {
            margin-bottom: 15px;
        }
        
        .skill-name {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        
        .skill-bar {
            height: 10px;
            background-color: #EDF2F7;
            border-radius: 5px;
            overflow: hidden;
        }
        
        .skill-progress {
            height: 100%;
            background: linear-gradient(to right, var(--primary), var(--accent));
            border-radius: 5px;
        }
        
        /* === BLOG SECTION === */
        .blog {
            background-color: #F7FAFC;
        }
        
        .blog-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
        }
        
        /* === GALLERY SECTION === */
        .gallery {
            background-color: white;
        }
        
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .gallery-item {
            position: relative;
            border-radius: 10px;
            overflow: hidden;
            height: 250px;
        }
        
        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }
        
        .gallery-item:hover img {
            transform: scale(1.1);
        }
        
        .gallery-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.7), transparent);
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 20px;
            color: white;
            opacity: 0;
            transition: var(--transition);
        }
        
        .gallery-item:hover .gallery-overlay {
            opacity: 1;
        }
        
        /* === FAQ SECTION === */
        .faq {
            background-color: #F7FAFC;
        }
        
        .accordion {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .accordion-item {
            margin-bottom: 15px;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: var(--shadow);
        }
        
        .accordion-header {
            padding: 15px 20px;
            background-color: white;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
        }
        
        .accordion-header i {
            transition: var(--transition);
        }
        
        .accordion-header.active i {
            transform: rotate(180deg);
        }
        
        .accordion-content {
            padding: 0 20px;
            max-height: 0;
            overflow: hidden;
            background-color: white;
            transition: max-height 0.3s ease;
        }
        
        .accordion-content-inner {
            padding: 15px 0;
        }
        
        /* === CONTACT SECTION === */
        .contact {
            background-color: white;
        }
        
        .contact-container {
            display: flex;
            gap: 50px;
        }
        
        .contact-info {
            flex: 1;
        }
        
        .contact-info-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 30px;
        }
        
        .contact-info-icon {
            width: 50px;
            height: 50px;
            background-color: var(--primary);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            flex-shrink: 0;
        }
        
        .contact-info-text h3 {
            font-size: 1.3rem;
            margin-bottom: 5px;
            color: var(--dark);
        }
        
        .contact-form {
            flex: 1;
            background-color: #F7FAFC;
            padding: 40px;
            border-radius: 10px;
            box-shadow: var(--shadow);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #E2E8F0;
            border-radius: 5px;
            font-family: inherit;
            transition: var(--transition);
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.2);
        }
        
        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }
        
        /* === FOOTER === */
        .footer {
            background-color: var(--dark);
            color: white;
            padding: 60px 0 20px;
        }
        
        .footer-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }
        
        .footer-logo {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 20px;
            display: inline-block;
        }
        
        .footer-about p {
            margin-bottom: 20px;
            opacity: 0.8;
        }
        
        .social-links {
            display: flex;
            gap: 15px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }
        
        .social-link:hover {
            background-color: var(--primary);
            transform: translateY(-5px);
        }
        
        .footer-title {
            font-size: 1.3rem;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 10px;
        }
        
        .footer-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 2px;
            background-color: var(--primary);
        }
        
        .footer-links {
            list-style: none;
        }
        
        .footer-link {
            margin-bottom: 10px;
            opacity: 0.8;
            transition: var(--transition);
        }
        
        .footer-link:hover {
            opacity: 1;
            color: var(--primary);
            padding-left: 5px;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            opacity: 0.8;
        }
        
        /* === RESPONSIVE === */
        @media (max-width: 992px) {
            .about-content {
                flex-direction: column;
            }
            
            .contact-container {
                flex-direction: column;
            }
        }
        
        @media (max-width: 768px) {
            .nav-menu {
                position: fixed;
                top: 0;
                right: -100%;
                width: 80%;
                max-width: 400px;
                height: 100vh;
                background-color: white;
                flex-direction: column;
                padding: 80px 30px;
                box-shadow: -5px 0 15px rgba(0, 0, 0, 0.1);
                transition: var(--transition);
                z-index: 999;
            }
            
            .nav-menu.active {
                right: 0;
            }
            
            .nav-item {
                margin: 0 0 20px 0;
            }
            
            .dropdown-menu {
                position: static;
                box-shadow: none;
                opacity: 1;
                visibility: visible;
                display: none;
                padding-left: 20px;
            }
            
            .dropdown.active .dropdown-menu {
                display: block;
            }
            
            .hamburger {
                display: flex;
                z-index: 1000;
            }
            
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-subtitle {
                font-size: 1.2rem;
            }
            
            .section-title {
                font-size: 2rem;
            }
        }
        
        @media (max-width: 576px) {
            .hero-buttons {
                flex-direction: column;
                gap: 10px;
            }
            
            .btn {
                width: 100%;
            }
            
            .section {
                padding: 60px 0;
            }
        }
    </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar">
        <div class="container navbar-container">
            <a href="index.php" class="logo">MAIS<span>AA</span></a>
            
            <ul class="nav-menu">
                <li class="nav-item"><a href="#anasayfa" class="nav-link active">Anasayfa</a></li>
                
                <li class="nav-item dropdown">
                    <a href="#hakkimda" class="nav-link">Hakkımda <i class="fas fa-chevron-down"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="#biyografi" class="dropdown-item">Biyografi</a></li>
                        <li><a href="#ilgi-alanlari" class="dropdown-item">İlgi Alanları</a></li>
                        <li><a href="#egitim" class="dropdown-item">Eğitim</a></li>
                        <li><a href="#sertifikalar" class="dropdown-item">Sertifikalar</a></li>
                    </ul>
                </li>
                
                <li class="nav-item dropdown">
                    <a href="#blog" class="nav-link">Blog <i class="fas fa-chevron-down"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="#kisisel-yazilar" class="dropdown-item">Kişisel Yazılar</a></li>
                        <li><a href="#seyahat" class="dropdown-item">Seyahat Notları</a></li>
                        <li><a href="#kitap-film" class="dropdown-item">Kitap & Film</a></li>
                        <li><a href="#teknoloji" class="dropdown-item">Teknoloji</a></li>
                    </ul>
                </li>
                
                <li class="nav-item dropdown">
                    <a href="#galeri" class="nav-link">Galeri <i class="fas fa-chevron-down"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="#Fotoğraflarım" class="dropdown-item">Fotoğraflarım</a></li>
                        <li><a href="#Hobilerimle İlgili Görseller" class="dropdown-item">Hobilerimle İlgili Görseller</a></li>
                        <li><a href="#Video & Multimedya İçerikleri
" class="dropdown-item">Video & Multimedya İçerikleri
                        </a></li>
                    </ul>
                </li>
                <li class="nav-item"><a href="#sss" class="nav-link">SSS</a></li>
                <li class="nav-item"><a href="#iletisim" class="nav-link">İletişim</a></li>
                <li class="nav-item"><a href="./admin.php" class="btn btn-secondary">Admin</a></li>
            </ul>
            
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero" id="anasayfa">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">Merhaba, Ben Maisaa Alkhedr</h1>
                <p class="hero-subtitle">Bilgisayar Programcılığı öğrencisiyim. Teknoloji ve yazılım geliştirme alanında kendimi geliştiriyorum. Burada öğrenme sürecimi ve deneyimlerimi paylaşıyorum.</p>
                <div class="hero-buttons">
                    <a href="#blog" class="btn">Blog Yazılarım</a>
                    <a href="#iletisim" class="btn btn-outline">İletişime Geç</a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="section about" id="hakkimda">
        <div class="container">
            <h2 class="section-title">Hakkımda</h2>
            <p class="section-subtitle">Kendimi ve öğrenim sürecimi daha yakından tanıyın</p>
            
            <div class="about-content">
                <div class="about-img">
                    <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80" alt="Maisaa Alkhedr">
                </div>
                <div class="about-text">
                    <h3>Bilgisayar Programcılığı Öğrencisi</h3>
                    <p>Merhaba, ben Maisaa Alkhedr. Üniversitede Bilgisayar Programcılığı bölümünde öğrenim görüyorum. Yazılım geliştirme ve programlama dünyasına adım attım ve her gün yeni şeyler öğreniyorum.</p>
                    <p>Kod yazmayı, problem çözmeyi ve yeni teknolojileri keşfetmeyi seviyorum. Boş zamanlarımda kişisel projeler geliştiriyor ve açık kaynak projelere katkı sağlamaya çalışıyorum.</p>
                    
                    <div class="skills">
                        <div class="skill-item">
                            <div class="skill-name">
                                <span>Python Programlama</span>
                                <span>80%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 80%"></div>
                            </div>
                        </div>
                        
                        <div class="skill-item">
                            <div class="skill-name">
                                <span>Web Geliştirme</span>
                                <span>75%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 75%"></div>
                            </div>
                        </div>
                        
                        <div class="skill-item">
                            <div class="skill-name">
                                <span>Veritabanı Yönetimi</span>
                                <span>70%</span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" style="width: 70%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Blog Section -->
    <section class="section blog" id="blog">
        <div class="container">
            <h2 class="section-title">Son Blog Yazıları</h2>
            <p class="section-subtitle">Öğrenme sürecimde paylaştığım yazılar ve deneyimler</p>
            
            <div class="blog-grid">
                <?php while ($row = $random_blog_posts->fetch_assoc()): ?>
                <div class="card">
                    <div class="card-img">
                        <img src="https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" alt="<?= htmlspecialchars($row['baslik']) ?>">
                    </div>
                    <div class="card-body">
                        <h3 class="card-title"><?= htmlspecialchars($row['baslik']) ?></h3>
                        <p class="card-text"><?= substr(htmlspecialchars($row['icerik']), 0, 100) ?>...</p>
                        <div class="card-date">
                            <i class="far fa-calendar-alt"></i> <?= date('d.m.Y', strtotime($row['tarih'])) ?>
                        </div>
                        <a href="#" class="btn btn-outline" style="margin-top: 15px;">Devamını Oku</a>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section class="section gallery" id="galeri">
        <div class="container">
            <h2 class="section-title">Galeri</h2>
            <p class="section-subtitle">Öğrenim sürecimden görseller ve projelerim</p>
            
            <div class="gallery-grid">
                <?php while ($row = $galeri_icerikleri->fetch_assoc()): ?>
                <div class="gallery-item">
                    <img src="<?= htmlspecialchars($row['resim_yolu']) ?>" alt="<?= htmlspecialchars($row['aciklama']) ?>">
                    <div class="gallery-overlay">
                        <h3><?= htmlspecialchars($row['aciklama']) ?></h3>
                        <p><?= htmlspecialchars($row['kategori']) ?></p>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="section faq" id="sss">
        <div class="container">
            <h2 class="section-title">Sıkça Sorulan Sorular</h2>
            <p class="section-subtitle">Öğrencilik hayatıma dair en çok sorulan sorular</p>
            
            <div class="accordion">
                <div class="accordion-item">
                    <div class="accordion-header">
                        <span>Bilgisayar Programcılığına nasıl başladınız?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="accordion-content">
                        <div class="accordion-content-inner">
                            <p>Lisede bilgisayarlara ilgi duymaya başladım ve üniversitede bu alanda eğitim almaya karar verdim. İlk başta temel programlama kavramlarını öğrenerek başladım, şimdi daha karmaşık projeler üzerinde çalışıyorum.</p>
                        </div>
                    </div>
                </div>
                
                <div class="accordion-item">
                    <div class="accordion-header">
                        <span>Hangi programlama dillerini öğreniyorsunuz?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="accordion-content">
                        <div class="accordion-content-inner">
                            <p>Şu anda Python, Java ve C# gibi diller üzerinde çalışıyorum. Ayrıca web geliştirme için HTML, CSS ve JavaScript öğreniyorum. Okul müfredatımızda bu dillerin temellerini görüyoruz.</p>
                        </div>
                    </div>
                </div>
                
                <div class="accordion-item">
                    <div class="accordion-header">
                        <span>Mezun olduktan sonra hedefleriniz neler?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="accordion-content">
                        <div class="accordion-content-inner">
                            <p>Mezun olduktan sonra yazılım geliştirici olarak çalışmayı hedefliyorum. Özellikle web ve mobil uygulama geliştirme alanlarında uzmanlaşmak istiyorum. Ayrıca yapay zeka ve veri bilimi alanlarında da kendimi geliştirmeyi planlıyorum.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="section contact" id="iletisim">
        <div class="container">
            <h2 class="section-title">İletişim</h2>
            <p class="section-subtitle">Bana ulaşmak için aşağıdaki bilgileri kullanabilirsiniz</p>
            
            <div class="contact-container">
                <div class="contact-info">
                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="contact-info-text">
                            <h3>Adres</h3>
                            <p>1234 Sokak, No:5678<br>İstanbul, Türkiye</p>
                        </div>
                    </div>
                    
                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="contact-info-text">
                            <h3>Email</h3>
                            <p>maisaa.ogrenci@universite.edu.tr</p>
                        </div>
                    </div>
                    
                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="contact-info-text">
                            <h3>Telefon</h3>
                            <p>+90 537 299 97 34</p>
                        </div>
                    </div>
                </div>
                
                <div class="contact-form">
                    <form action="#" method="post">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Adınız" required>
                        </div>
                        
                        <div class="form-group">
                            <input type="email" class="form-control" placeholder="Email Adresiniz" required>
                        </div>
                        
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Konu">
                        </div>
                        
                        <div class="form-group">
                            <textarea class="form-control" placeholder="Mesajınız" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn">Mesaj Gönder</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-container">
                <div class="footer-about">
                    <a href="#" class="footer-logo">MAIS<span>AA</span></a>
                    <p>Bilgisayar Programcılığı öğrencisi olarak öğrenme sürecimi ve teknoloji deneyimlerimi paylaştığım kişisel blog sayfam.</p>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                
                <div class="footer-links">
                    <h3 class="footer-title">Hızlı Linkler</h3>
                    <ul>
                        <li><a href="#anasayfa" class="footer-link">Anasayfa</a></li>
                        <li><a href="#hakkimda" class="footer-link">Hakkımda</a></li>
                        <li><a href="#blog" class="footer-link">Blog</a></li>
                        <li><a href="#galeri" class="footer-link">Galeri</a></li>
                        <li><a href="#iletisim" class="footer-link">İletişim</a></li>
                    </ul>
                </div>
                
                <div class="footer-links">
                    <h3 class="footer-title">Blog Kategorileri</h3>
                    <ul>
                        <li><a href="#kisisel-yazilar" class="footer-link">Kişisel Yazılar</a></li>
                        <li><a href="#seyahat" class="footer-link">Seyahat Notları</a></li>
                        <li><a href="#kitap-film" class="footer-link">Kitap & Film</a></li>
                        <li><a href="#teknoloji" class="footer-link">Teknoloji</a></li>
                    </ul>
                </div>
                
                <div class="footer-links">
                    <h3 class="footer-title">İletişim Bilgileri</h3>
                    <ul>
                        <li class="footer-link">1234 Sokak, İstanbul</li>
                        <li class="footer-link">maisaa.ogrenci@universite.edu.tr</li>
                        <li class="footer-link">+90 537 299 97 34</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2025 Maisaa Alkhedr. Tüm hakları saklıdır.</p>
            </div>
        </div>
    </footer>

    <script>
        // Mobile Menu Toggle
        const hamburger = document.querySelector('.hamburger');
        const navMenu = document.querySelector('.nav-menu');
        const dropdowns = document.querySelectorAll('.dropdown');
        
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        
        // Close menu when clicking a link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
        
        // Dropdown functionality for mobile
        dropdowns.forEach(dropdown => {
            const link = dropdown.querySelector('.nav-link');
            
            link.addEventListener('click', (e) => {
                if (window.innerWidth <= 768) {
                    e.preventDefault();
                    dropdown.classList.toggle('active');
                }
            });
        });
        
        // Sticky navbar on scroll
        window.addEventListener('scroll', () => {
            const navbar = document.querySelector('.navbar');
            navbar.classList.toggle('scrolled', window.scrollY > 0);
        });
        
        // Accordion functionality
        const accordionHeaders = document.querySelectorAll('.accordion-header');
        
        accordionHeaders.forEach(header => {
            header.addEventListener('click', () => {
                const accordionItem = header.parentElement;
                const accordionContent = header.nextElementSibling;
                
                // Close other open items
                document.querySelectorAll('.accordion-item').forEach(item => {
                    if (item !== accordionItem && item.classList.contains('active')) {
                        item.classList.remove('active');
                        item.querySelector('.accordion-content').style.maxHeight = null;
                    }
                });
                
                // Toggle current item
                accordionItem.classList.toggle('active');
                
                if (accordionItem.classList.contains('active')) {
                    accordionContent.style.maxHeight = accordionContent.scrollHeight + 'px';
                } else {
                    accordionContent.style.maxHeight = null;
                }
            });
        });
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
        
        // Set active link based on scroll position
        const sections = document.querySelectorAll('section');
        
        window.addEventListener('scroll', () => {
            let current = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (pageYOffset >= sectionTop - 200) {
                    current = section.getAttribute('id');
                }
            });
            
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${current}`) {
                    link.classList.add('active');
                }
            });
        });
        
        // Generate random dates for blog posts
        function getRandomDate(start, end) {
            const startDate = start.getTime();
            const endDate = end.getTime();
            const randomTime = startDate + Math.random() * (endDate - startDate);
            return new Date(randomTime);
        }
        
        function displayRandomDates() {
            const start = new Date(2025, 0, 1);
            const end = new Date(2025, 11, 31);
            const dateElements = document.querySelectorAll('.card-date');
            
            dateElements.forEach(element => {
                const randomDate = getRandomDate(start, end);
                element.innerHTML = `<i class="far fa-calendar-alt"></i> ${randomDate.toLocaleDateString('tr-TR')}`;
            });
        }
        
        window.addEventListener('load', displayRandomDates);
    </script>
</body>
</html>