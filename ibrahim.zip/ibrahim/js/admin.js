// Document Ready
document.addEventListener('DOMContentLoaded', function() {
    // Mobile Sidebar Toggle
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.admin-sidebar');
    const adminMain = document.querySelector('.admin-main');
    
    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('active');
        adminMain.classList.toggle('sidebar-collapsed');
    });
    
    // Hash-based Tab Navigation
    window.addEventListener('hashchange', function() {
        showSection(window.location.hash);
    });
    
    // Show section based on hash on initial load
    if (window.location.hash) {
        showSection(window.location.hash);
    } else {
        showSection('#dashboard');
    }
    
    function showSection(sectionId) {
        // Hide all sections
        document.querySelectorAll('.admin-section').forEach(section => {
            section.style.display = 'none';
        });
        
        // Show selected section
        const section = document.querySelector(sectionId);
        if (section) {
            section.style.display = 'block';
        }
        
        // Update active link in sidebar
        document.querySelectorAll('.sidebar-nav a').forEach(link => {
            link.classList.remove('active');
            
            if (link.getAttribute('href') === sectionId) {
                link.classList.add('active');
            }
        });
    }
    
    // Confirmation for delete actions
    document.querySelectorAll('a[onclick*="confirm"]').forEach(link => {
        link.addEventListener('click', function(e) {
            if (!confirm('Bu işlemi gerçekleştirmek istediğinize emin misiniz?')) {
                e.preventDefault();
            }
        });
    });
    
    // Form validation
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            
            this.querySelectorAll('[required]').forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.style.borderColor = 'red';
                    
                    setTimeout(() => {
                        input.style.borderColor = '#ddd';
                    }, 2000);
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Lütfen tüm gerekli alanları doldurunuz!');
            }
        });
    });
    
    // File input preview
    document.querySelectorAll('input[type="file"]').forEach(input => {
        input.addEventListener('change', function() {
            const preview = this.nextElementSibling;
            if (preview && preview.classList.contains('file-preview')) {
                if (this.files && this.files[0]) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        preview.innerHTML = `<img src="${e.target.result}" alt="Preview" style="max-width: 100%; max-height: 200px;">`;
                    }
                    
                    reader.readAsDataURL(this.files[0]);
                }
            }
        });
    });
});