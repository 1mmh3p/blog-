-- phpMyAdmin SQL 
-- version 8.3.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 04 Nis 2025, 22:11:14
-- Sunucu sürümü: 8.0.17
-- PHP Sürümü: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ibrahim_web_proje`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `baslik` varchar(255) NOT NULL,
  `icerik` text NOT NULL,
  `kategori` enum('kişisel','seyahat','kitap-film','teknoloji') NOT NULL,
  `kapak_resmi` varchar(255) DEFAULT NULL,
  `yayin_tarihi` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `guncellenme_tarihi` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `goruntulenme` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `blog`
--

INSERT INTO `blog` (`id`, `baslik`, `icerik`, `kategori`, `kapak_resmi`, `yayin_tarihi`, `goruntulenme`) VALUES
(1, 'Seyahat Notları: Gizli Ada', 'Pasifik Okyanusu\'nda keşfedilmemiş bir adaya yolculuk yaptık. Berrak suları, el değmemiş doğası ve egzotik vahşi yaşamı ile adeta bir cennet gibiydi. Teknolojiden uzak birkaç gün geçirmek, doğayla iç içe olmanın ne kadar değerli olduğunu hatırlattı.', 'seyahat', NULL, '2025-04-04 01:17:27', 0),
(2, 'Kitap Önerisi: Zamanın Kıyısında', 'Bilim kurgu severler için harika bir öneri: \"Zamanın Kıyısında\". Kitap, zaman yolculuğu yaparak geçmişi değiştirmeye çalışan bir adamın hikayesini anlatıyor. Akıcı anlatımı ve düşündürücü kurgusuyla okuyucuları içine çekiyor.', 'kitap-film', NULL, '2025-04-04 01:17:27', 0),
(3, 'Teknoloji: Yapay Zeka ve İnsan Beyni', 'Yapay zeka, son yıllarda insan beyninin çalışma prensiplerine daha fazla benzetilmeye başlandı. Derin öğrenme ve sinir ağları üzerine yapılan çalışmalar, nörolojik hastalıkların tedavisine yönelik yeni umutlar sunuyor.', 'teknoloji', NULL, '2025-04-04 01:17:27', 0),
(4, 'Günlük Hayat: Verimli Çalışma Teknikleri', 'Zaman yönetimi ve odaklanma becerileri, başarılı bir çalışma rutini oluşturmanın temel taşlarıdır. Pomodoro tekniği, dikkat dağıtıcı unsurları en aza indirerek daha verimli çalışmayı sağlar.', 'kişisel', NULL, '2025-04-04 01:17:27', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `galeri`
--

CREATE TABLE `galeri` (
  `id` int(11) NOT NULL,
  `resim_yolu` varchar(255) NOT NULL,
  `aciklama` text,
  `kategori` enum('fotograf','hobi','video') NOT NULL,
  `eklenme_tarihi` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `galeri`
--

INSERT INTO `galeri` (`id`, `resim_yolu`, `aciklama`, `kategori`, `eklenme_tarihi`) VALUES
(1, 'image/ben.jpg', 'Benim fotoğrafım', 'fotograf', '2025-04-04 01:17:27'),
(2, 'image/me.jpg', 'Resim çalışmam', 'hobi', '2025-04-04 01:17:27'),
(3, 'image/ben.jpg', 'Gezi vlog\'undan', 'video', '2025-04-04 01:17:27');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakkimda`
--

CREATE TABLE `hakkimda` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `icerik` text NOT NULL,
  `resim_yolu` varchar(255) DEFAULT NULL,
  `guncellenme_tarihi` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `hakkimda`
--

INSERT INTO `hakkimda` (`id`, `baslik`, `icerik`, `resim_yolu`) VALUES
(1, 'Biyografi', '2002 yılında doğdum.\r\nMersinde yaşıyorum. Mersin üniversitesinde Bilgisayar programcılığı eğitimi alıyorum.', NULL),
(2, 'İlgi Alanlarım', 'Futbol oynamak, maç izlemek, dizi/film izlemek, kitap okumak başlıca ilgi alanlarım.', NULL),
(3, 'Eğitim ve Deneyim', 'Üniversite eğitimimi bilgisayar programcılığı 2. Sınıf öğrencisi olarak devam ediyorum. Ekstradan yazılım geliştirme alanında kendimi geliştiriyorum.', NULL),
(4, 'Başarılar & Sertifikalar', 'Yazılım geliştirme alanında bir çok sertifika ve başarıya imza attım.', NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iletisim_mesajlari`
--

CREATE TABLE `iletisim_mesajlari` (
  `id` int(11) NOT NULL,
  `ad_soyad` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `konu` varchar(100) NOT NULL,
  `mesaj` text NOT NULL,
  `okundu` tinyint(1) DEFAULT '0',
  `gonderim_tarihi` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE `kullanicilar` (
  `id` int(11) NOT NULL,
  `kullanici_adi` varchar(50) NOT NULL,
  `sifre` varchar(255) NOT NULL,
  `yetki_seviyesi` int(11) DEFAULT '1',
  `olusturulma_tarihi` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`id`, `kullanici_adi`, `sifre`, `yetki_seviyesi`, `olusturulma_tarihi`) VALUES
(1, 'ibrahim', 'ibrahim123', 99, '2025-04-04 01:17:27');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sss`
--

CREATE TABLE `sss` (
  `id` int(11) NOT NULL,
  `soru` varchar(255) NOT NULL,
  `cevap` text NOT NULL,
  `eklenme_tarihi` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `sss`
--

INSERT INTO `sss` (`id`, `soru`, `cevap`, `eklenme_tarihi`) VALUES
(1, 'Nasıl kodlama öğrenmeye başladınız?', 'Üniversiteye başladığımda, temel programlama dersleri ile kodlamaya ilk adımımı attım.', '2025-04-04 01:17:27'),
(2, 'Hangi teknolojilere hakim oldunuz?', 'HTML, CSS, JavaScript, PHP ve Python gibi teknolojileri kullanabiliyorum.', '2025-04-04 01:17:27'),
(3, 'Yeni başlayanlara ne tavsiye ediyorsunuz?', 'Öncelikle programlamanın temellerini öğrenmek ve bolca pratik yapmak önemli.', '2025-04-04 01:17:27');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `hakkimda`
--
ALTER TABLE `hakkimda`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `iletisim_mesajlari`
--
ALTER TABLE `iletisim_mesajlari`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kullanicilar`
--
ALTER TABLE `kullanicilar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kullanici_adi` (`kullanici_adi`);

--
-- Tablo için indeksler `sss`
--
ALTER TABLE `sss`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `galeri`
--
ALTER TABLE `galeri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tablo için AUTO_INCREMENT değeri `hakkimda`
--
ALTER TABLE `hakkimda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `iletisim_mesajlari`
--
ALTER TABLE `iletisim_mesajlari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `kullanicilar`
--
ALTER TABLE `kullanicilar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `sss`
--
ALTER TABLE `sss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
