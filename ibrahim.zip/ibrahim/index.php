<?php
// Veritabanı bağlantısı
$db = new mysqli('localhost', 'root', 'admin#123', 'ibrahim_web_proje');

// Rastgele 3 blog yazısı çek
$random_posts = $db->query("SELECT * FROM blog ORDER BY RAND() LIMIT 3");

// Galeri içerikleri
$galeri_icerikleri = $db->query("SELECT * FROM galeri ORDER BY eklenme_tarihi DESC");

// SSS listesi
$sss_listesi = $db->query("SELECT * FROM sss ORDER BY id ASC");

// Hakkımda bölümleri
$hakkimda_bilgileri = $db->query("SELECT * FROM hakkimda");
$hakkimda_data = [];
while ($row = $hakkimda_bilgileri->fetch_assoc()) {
    $hakkimda_data[$row['baslik']] = $row;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ibrahim. - Kişisel Web Sitesi</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="./js/script.js"></script>

</head>
<body>
    <!-- Yükleniyor Animasyonu -->
    <div class="loader">
        <div class="loader-inner">
            <div class="loader-line-wrap">
                <div class="loader-line"></div>
            </div>
            <div class="loader-line-wrap">
                <div class="loader-line"></div>
            </div>
            <div class="loader-line-wrap">
                <div class="loader-line"></div>
            </div>
            <div class="loader-line-wrap">
                <div class="loader-line"></div>
            </div>
            <div class="loader-line-wrap">
                <div class="loader-line"></div>
            </div>
        </div>
    </div>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="logo">ibrahim<span>.</span></a>
            <ul class="nav-links">
                <li><a href="#home">Anasayfa</a></li>
                <li class="dropdown">
                    <a href="#about">Hakkımda <i class="fas fa-chevron-down"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="#biyografi">Biyografi</a></li>
                        <li><a href="#ilgi-alanlarim">İlgi Alanlarım</a></li>
                        <li><a href="#egitim">Eğitim ve Deneyim</a></li>
                        <li><a href="#basari">Başarılar & Sertifikalar</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#blog">Blog <i class="fas fa-chevron-down"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="#kisisel">Kişisel Yazılar</a></li>
                        <li><a href="#seyahat">Seyahat Notları</a></li>
                        <li><a href="#kitap-film">Kitap & Film Önerileri</a></li>
                        <li><a href="#teknoloji">Teknoloji & İlgi Alanları</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#galeri">Galeri <i class="fas fa-chevron-down"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="#fotograflar">Fotoğraflarım</a></li>
                        <li><a href="#hobiler">Hobilerim</a></li>
                        <li><a href="#videolar">Videolar</a></li>
                    </ul>
                </li>
                <li><a href="#sss">SSS</a></li>
                <li><a href="#iletisim">İletişim</a></li>
                <li><a href="admin.php" class="admin-btn">Admin Paneli</a></li>
            </ul>
            <div class="menu-toggle">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="hero-overlay"></div>
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">Hoş Geldiniz, Ben ibrahim</h1>
                <p class="hero-subtitle">Bilgisayar Programcılığı öğrencisi ve teknoloji tutkunu</p>
                <a href="#about" class="btn btn-primary">Daha Fazla Bilgi</a>
                <br><br><br>
                <p><a href="#blog" class="admin-btn">Son 3 Blog Yazılarım </a></p>
                
            </div>
        </div>
        <div class="scroll-down">
            <a href="#about"><i class="fas fa-chevron-down"></i></a>
        </div>
    </section>

    <!-- About Section -->
    <section class="section about-section" id="about">
        <div class="container">
            <h2 class="section-title">Hakkımda</h2>
            <div class="about-grid">
                <article class="about-card" id="biyografi">
                    <div class="about-icon">
                        <i class="fas fa-user"></i>
                    </div>
                    <h3>Biyografi</h3>
                    <p><?= htmlspecialchars($hakkimda_data['Biyografi']['icerik']) ?></p>
                </article>
                
                <article class="about-card" id="ilgi-alanlarim">
                    <div class="about-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h3>İlgi Alanlarım</h3>
                    <p><?= htmlspecialchars($hakkimda_data['İlgi Alanlarım']['icerik']) ?></p>
                </article>
                
                <article class="about-card" id="egitim">
                    <div class="about-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <h3>Eğitim ve Deneyim</h3>
                    <p><?= htmlspecialchars($hakkimda_data['Eğitim ve Deneyim']['icerik']) ?></p>
                </article>
                
                <article class="about-card" id="basari">
                    <div class="about-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <h3>Başarılar & Sertifikalar</h3>
                    <p><?= htmlspecialchars($hakkimda_data['Başarılar & Sertifikalar']['icerik']) ?></p>
                </article>
            </div>
        </div>
    </section>

    <!-- Blog Section -->
    <section class="section blog-section" id="blog">
        <div class="container">
            <h2 class="section-title">Son Blog Yazılarım</h2>
            <div class="blog-grid">
                <?php while ($post = $random_posts->fetch_assoc()): ?>
                <article class="blog-card">
                    <div class="blog-image">
                        <img src="https://st.depositphotos.com/56341270/59933/i/450/depositphotos_599335142-stock-photo-quote-blank-chat-bubble-sign.jpg" alt="<?= htmlspecialchars($post['baslik']) ?>">
                    </div>
                    <div class="blog-content">
                        <span class="blog-category"><?= ucfirst($post['kategori']) ?></span>
                        <h3><?= htmlspecialchars($post['baslik']) ?></h3>
                        <p><?= substr(htmlspecialchars($post['icerik']), 0, 150) ?>...</p>
                        <a href="#" class="read-more">Oku<i class="fas fa-arrow-right"></i></a>
                    </div>
                </article>
                <?php endwhile; ?>
            </div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <div class="blog-categories">
                <h3>Blog Kategorileri</h3>
                <div class="categories-grid">
                    <div class="category-card" id="kisisel">
                        <i class="fas fa-pen"></i>
                        <h4>Kişisel Yazılar</h4>
                    </div>
                    <div class="category-card" id="seyahat">
                        <i class="fas fa-plane"></i>
                        <h4>Seyahat Notları</h4>
                    </div>
                    <div class="category-card" id="kitap-film">
                        <i class="fas fa-book"></i>
                        <h4>Kitap & Film</h4>
                    </div>
                    <div class="category-card" id="teknoloji">
                        <i class="fas fa-laptop-code"></i>
                        <h4>Teknoloji</h4>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section class="section gallery-section" id="galeri">
        <div class="container">
            <h2 class="section-title">Galeri</h2>
            
            <div class="gallery-tabs">
                <button class="tab-btn active" data-tab="fotograflar">Fotoğraflarım</button>
                <button class="tab-btn" data-tab="hobiler">Hobilerim</button>
                <button class="tab-btn" data-tab="videolar">Videolar</button>
            </div>
            
            <div class="gallery-content">
                <div class="tab-panel active" id="fotograflar">
                    <div class="gallery-grid">
                        <?php while ($item = $galeri_icerikleri->fetch_assoc()): ?>
                        <?php if ($item['kategori'] == 'fotograf'): ?>
                        <div class="gallery-item">
                            <img src="<?= htmlspecialchars($item['resim_yolu']) ?>" alt="<?= htmlspecialchars($item['aciklama']) ?>">
                            <div class="gallery-overlay">
                                <p><?= htmlspecialchars($item['aciklama']) ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endwhile; ?>
                    </div>
                </div>
                
                <div class="tab-panel" id="hobiler">
                    <div class="gallery-grid">
                        <?php $galeri_icerikleri->data_seek(0); ?>
                        <?php while ($item = $galeri_icerikleri->fetch_assoc()): ?>
                        <?php if ($item['kategori'] == 'hobi'): ?>
                        <div class="gallery-item">
                            <img src="<?= htmlspecialchars($item['resim_yolu']) ?>" alt="<?= htmlspecialchars($item['aciklama']) ?>">
                            <div class="gallery-overlay">
                                <p><?= htmlspecialchars($item['aciklama']) ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endwhile; ?>
                    </div>
                </div>
                
                <div class="tab-panel" id="videolar">
                    <div class="gallery-grid">
                        <?php $galeri_icerikleri->data_seek(0); ?>
                        <?php while ($item = $galeri_icerikleri->fetch_assoc()): ?>
                        <?php if ($item['kategori'] == 'video'): ?>
                        <div class="gallery-item">
                            <img src="<?= htmlspecialchars($item['resim_yolu']) ?>" alt="<?= htmlspecialchars($item['aciklama']) ?>">
                            <div class="gallery-overlay">
                                <p><?= htmlspecialchars($item['aciklama']) ?></p>
                                <i class="fas fa-play"></i>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="section faq-section" id="sss">
        <div class="container">
            <h2 class="section-title">Sıkça Sorulan Sorular</h2>
            <div class="faq-container">
                <?php while ($sss = $sss_listesi->fetch_assoc()): ?>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3><?= htmlspecialchars($sss['soru']) ?></h3>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?= htmlspecialchars($sss['cevap']) ?></p>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="section contact-section" id="iletisim">
        <div class="container">
            <h2 class="section-title">İletişim</h2>
            <div class="contact-grid">
                <div class="contact-info">
                    <h3>Bana Ulaşın</h3>
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <p>ibrahimozupak01@gmail.com</p>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-phone"></i>
                        <p>+90 530 614 49 33</p>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <p>Mersin, Türkiye</p>
                    </div>
                    
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-github"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                
                <form class="contact-form" method="post" action="iletisim.php">
                    <div class="form-group">
                        <input type="text" name="ad_soyad" placeholder="Adınız Soyadınız" required>
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" placeholder="E-posta Adresiniz" required>
                    </div>
                    <div class="form-group">
                        <input type="text" name="konu" placeholder="Konu" required>
                    </div>
                    <div class="form-group">
                        <textarea name="mesaj" placeholder="Mesajınız" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Gönder</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <h3>ibrahim</h3>
                    <p>Bilgisayar Programcılığı öğrencisi ve teknoloji tutkunu. Burada deneyimlerimi ve projelerimi paylaşıyorum.</p>
                </div>
                
                <div class="footer-links">
                    <h3>Hızlı Linkler</h3>
                    <ul>
                        <li><a href="#home">Anasayfa</a></li>
                        <li><a href="#about">Hakkımda</a></li>
                        <li><a href="#blog">Blog</a></li>
                        <li><a href="#galeri">Galeri</a></li>
                        <li><a href="#iletisim">İletişim</a></li>
                    </ul>
                </div>
                
                <div class="footer-contact">
                    <h3>İletişim</h3>
                    <p><i class="fas fa-envelope"></i> ibrahimozupak01@gmail.com</p>
                    <p><i class="fas fa-phone"></i> +90 530 614 49 33</p>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2024 ibrahim. Tüm hakları saklıdır.</p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="back-to-top"><i class="fas fa-arrow-up"></i></a>

    <script src="./js/admin.js"></script>
</body>
</html>