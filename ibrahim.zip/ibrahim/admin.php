<?php
session_start();
$db = new mysqli('localhost', 'root', 'admin#123', 'ibrahim_web_proje');

// Kullanıcı giriş kontrolü
//if (!isset($_SESSION['admin_giris'])) {
//    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//        $kullanici_adi = $db->real_escape_string($_POST['kullanici_adi']);
//        $sifre = $_POST['sifre'];
//        
//        $sorgu = $db->query("SELECT * FROM kullanicilar WHERE kullanici_adi = '$kullanici_adi'");
//        
//        if ($sorgu->num_rows > 0) {
//            $kullanici = $sorgu->fetch_assoc();
//            
//            if (password_verify($sifre, $kullanici['sifre']) && $kullanici['yetki_seviyesi'] >= 10) {
//                $_SESSION['admin_giris'] = true;
//                $_SESSION['admin_id'] = $kullanici['id'];
//                $_SESSION['admin_adi'] = $kullanici['kullanici_adi'];
//                header("Location: admin.php");
//                exit();
//            } else {
//                $hata = "Hatalı şifre veya yetkiniz yok!";
//            }
//        } else {
//            $hata = "Kullanıcı bulunamadı!";
//        }
//    }
    // Admin bilgileri
define('ADMIN_USER', 'ibrahim');
define('ADMIN_PASS', 'ibrahim123');
$hashed_admin_pass = password_hash(ADMIN_PASS, PASSWORD_BCRYPT);

// Çıkış işlemi
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit();
}

// Giriş kontrolü
if (!isset($_SESSION['giris_yapildi'])) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $kullanici_adi = $_POST['kullanici_adi'];
        $sifre = $_POST['sifre'];
        
        if ($kullanici_adi === ADMIN_USER && password_verify($sifre, $hashed_admin_pass)) {
            $_SESSION['giris_yapildi'] = true;
            header("Location: admin.php");
            exit();
        } else {
            $error_message = "Hatalı kullanıcı adı veya şifre!";
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Girişi</title>
        <link rel="stylesheet" href="./css/admin.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    </head>
    <body>
        <div class="login-container">
            <div class="login-box">
                <div class="login-header">
                    <h2>Admin Girişi</h2>
                    <p>Lütfen bilgilerinizi giriniz</p>
                </div>
                
                <?php if (isset($hata)): ?>
                <div class="alert alert-danger">
                    <?= $hata ?>
                </div>
                <?php endif; ?>
                
                <form method="post" class="login-form">
                    <div class="form-group">
                        <label for="kullanici_adi"><i class="fas fa-user"></i> Kullanıcı Adı</label>
                        <input type="text" id="kullanici_adi" name="kullanici_adi" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="sifre"><i class="fas fa-lock"></i> Şifre</label>
                        <input type="password" id="sifre" name="sifre" required>
                    </div>
                    
                    <button type="submit" class="login-btn">Giriş Yap</button>
                </form>
                
                <div class="login-footer">
                    <a href="index.php"><i class="fas fa-home"></i> Siteye Dön</a>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}

// Çıkış işlemi
if (isset($_GET['cikis'])) {
    session_destroy();
    header("Location: admin.php");
    exit();
}

// Veri işlemleri
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Blog ekleme/güncelleme
    if (isset($_POST['blog_ekle'])) {
        $baslik = $db->real_escape_string($_POST['baslik']);
        $icerik = $db->real_escape_string($_POST['icerik']);
        $kategori = $db->real_escape_string($_POST['kategori']);
        
        if (empty($_POST['id'])) {
            $sorgu = $db->query("INSERT INTO blog (baslik, icerik, kategori) VALUES ('$baslik', '$icerik', '$kategori')");
            $mesaj = $sorgu ? "Blog yazısı başarıyla eklendi!" : "Hata: " . $db->error;
        } else {
            $id = (int)$_POST['id'];
            $sorgu = $db->query("UPDATE blog SET baslik='$baslik', icerik='$icerik', kategori='$kategori' WHERE id=$id");
            $mesaj = $sorgu ? "Blog yazısı başarıyla güncellendi!" : "Hata: " . $db->error;
        }
        
        $_SESSION['mesaj'] = ['tur' => $sorgu ? 'success' : 'danger', 'icerik' => $mesaj];
        header("Location: admin.php");
        exit();
    }
    
    // Galeri ekleme/güncelleme
    if (isset($_POST['galeri_ekle'])) {
        $aciklama = $db->real_escape_string($_POST['aciklama']);
        $kategori = $db->real_escape_string($_POST['kategori']);
        
        // Basit dosya yükleme (gerçek projede daha güvenli bir yöntem kullanılmalı)
        $hedef_dizin = "uploads/";
        $resim_yolu = $hedef_dizin . basename($_FILES['resim']['name']);
        
        if (move_uploaded_file($_FILES['resim']['tmp_name'], $resim_yolu)) {
            if (empty($_POST['id'])) {
                $sorgu = $db->query("INSERT INTO galeri (resim_yolu, aciklama, kategori) VALUES ('$resim_yolu', '$aciklama', '$kategori')");
                $mesaj = $sorgu ? "Galeri öğesi başarıyla eklendi!" : "Hata: " . $db->error;
            } else {
                $id = (int)$_POST['id'];
                // Eski resmi silmek isteyebilirsiniz
                $sorgu = $db->query("UPDATE galeri SET resim_yolu='$resim_yolu', aciklama='$aciklama', kategori='$kategori' WHERE id=$id");
                $mesaj = $sorgu ? "Galeri öğesi başarıyla güncellendi!" : "Hata: " . $db->error;
            }
        } else {
            $mesaj = "Resim yüklenirken hata oluştu!";
        }
        
        $_SESSION['mesaj'] = ['tur' => isset($sorgu) && $sorgu ? 'success' : 'danger', 'icerik' => $mesaj];
        header("Location: admin.php");
        exit();
    }
    
    // Hakkımda güncelleme
    if (isset($_POST['hakkimda_guncelle'])) {
        foreach ($_POST['hakkimda'] as $id => $icerik) {
            $id = (int)$id;
            $baslik = $db->real_escape_string($icerik['baslik']);
            $icerik = $db->real_escape_string($icerik['icerik']);
            
            $db->query("UPDATE hakkimda SET baslik='$baslik', icerik='$icerik' WHERE id=$id");
        }
        
        $_SESSION['mesaj'] = ['tur' => 'success', 'icerik' => 'Hakkımda bölümleri başarıyla güncellendi!'];
        header("Location: admin.php");
        exit();
    }
    
    // SSS ekleme/güncelleme
    if (isset($_POST['sss_ekle'])) {
        $soru = $db->real_escape_string($_POST['soru']);
        $cevap = $db->real_escape_string($_POST['cevap']);
        
        if (empty($_POST['id'])) {
            $sorgu = $db->query("INSERT INTO sss (soru, cevap) VALUES ('$soru', '$cevap')");
            $mesaj = $sorgu ? "SSS başarıyla eklendi!" : "Hata: " . $db->error;
        } else {
            $id = (int)$_POST['id'];
            $sorgu = $db->query("UPDATE sss SET soru='$soru', cevap='$cevap' WHERE id=$id");
            $mesaj = $sorgu ? "SSS başarıyla güncellendi!" : "Hata: " . $db->error;
        }
        
        $_SESSION['mesaj'] = ['tur' => $sorgu ? 'success' : 'danger', 'icerik' => $mesaj];
        header("Location: admin.php");
        exit();
    }
}

// Silme işlemleri
if (isset($_GET['sil'])) {
    $tablo = $db->real_escape_string($_GET['tablo']);
    $id = (int)$_GET['id'];
    
    $izinli_tablolar = ['blog', 'galeri', 'sss', 'iletisim_mesajlari'];
    
    if (in_array($tablo, $izinli_tablolar)) {
        $sorgu = $db->query("DELETE FROM $tablo WHERE id=$id");
        $mesaj = $sorgu ? "Kayıt başarıyla silindi!" : "Hata: " . $db->error;
        $_SESSION['mesaj'] = ['tur' => $sorgu ? 'success' : 'danger', 'icerik' => $mesaj];
    }
    
    header("Location: admin.php");
    exit();
}

// Verileri çekme
$blog_yazilari = $db->query("SELECT * FROM blog ORDER BY id DESC");
$galeri_icerikleri = $db->query("SELECT * FROM galeri ORDER BY id DESC");
$hakkimda_bilgileri = $db->query("SELECT * FROM hakkimda");
$sss_listesi = $db->query("SELECT * FROM sss ORDER BY id ASC");
$iletisim_mesajlari = $db->query("SELECT * FROM iletisim_mesajlari ORDER BY gonderim_tarihi DESC");
$kullanicilar = $db->query("SELECT * FROM kullanicilar ORDER BY id DESC");

// Düzenleme modu
$duzenle = null;
if (isset($_GET['duzenle'])) {
    $tablo = $db->real_escape_string($_GET['tablo']);
    $id = (int)$_GET['id'];
    
    $sorgu = $db->query("SELECT * FROM $tablo WHERE id=$id");
    if ($sorgu->num_rows > 0) {
        $duzenle = [
            'tablo' => $tablo,
            'veri' => $sorgu->fetch_assoc()
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli</title>
    <link rel="stylesheet" href="./css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="admin-sidebar">
            <div class="sidebar-header">
                <h2>Admin Paneli</h2>
                <p>Hoş geldiniz, <?= $_SESSION['admin_adi'] ?></p>
            </div>
            
            <nav class="sidebar-nav">
                <a href="#dashboard" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                <a href="#blog"><i class="fas fa-blog"></i> Blog Yönetimi</a>
                <a href="#galeri"><i class="fas fa-images"></i> Galeri Yönetimi</a>
                <a href="#hakkimda"><i class="fas fa-user"></i> Hakkımda Yönetimi</a>
                <a href="#sss"><i class="fas fa-question-circle"></i> SSS Yönetimi</a>
                <a href="#iletisim"><i class="fas fa-envelope"></i> İletişim Mesajları</a>
                <a href="#kullanicilar"><i class="fas fa-users"></i> Kullanıcı Yönetimi</a>
            </nav>
            
            <div class="sidebar-footer">
                <a href="?cikis=1" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Çıkış Yap</a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="admin-main">
            <header class="admin-header">
                <div class="header-left">
                    <button class="sidebar-toggle"><i class="fas fa-bars"></i></button>
                    <h1>Admin Paneli</h1>
                </div>
                <div class="header-right">
                    <a href="index.php" class="site-btn"><i class="fas fa-external-link-alt"></i> Siteyi Görüntüle</a>
                </div>
            </header>
            
            <main class="admin-content">
                <?php if (isset($_SESSION['mesaj'])): ?>
                <div class="alert alert-<?= $_SESSION['mesaj']['tur'] ?>">
                    <?= $_SESSION['mesaj']['icerik'] ?>
                </div>
                <?php unset($_SESSION['mesaj']); ?>
                <?php endif; ?>
                
                <!-- Dashboard -->
                <section id="dashboard" class="admin-section">
                    <h2 class="section-title">Genel Bakış</h2>
                    
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon bg-primary">
                                <i class="fas fa-blog"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?= $blog_yazilari->num_rows ?></h3>
                                <p>Blog Yazısı</p>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon bg-success">
                                <i class="fas fa-images"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?= $galeri_icerikleri->num_rows ?></h3>
                                <p>Galeri Öğesi</p>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon bg-warning">
                                <i class="fas fa-question-circle"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?= $sss_listesi->num_rows ?></h3>
                                <p>SSS</p>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon bg-danger">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?= $iletisim_mesajlari->num_rows ?></h3>
                                <p>İletişim Mesajı</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="recent-activity">
                        <h3>Son Aktiviteler</h3>
                        <div class="activity-list">
                            <div class="activity-item">
                                <div class="activity-icon">
                                    <i class="fas fa-blog"></i>
                                </div>
                                <div class="activity-content">
                                    <p>Son blog yazısı eklendi: <strong>"<?= $blog_yazilari->fetch_assoc()['baslik'] ?>"</strong></p>
                                    <small>2 gün önce</small>
                                </div>
                            </div>
                            
                            <div class="activity-item">
                                <div class="activity-icon">
                                    <i class="fas fa-images"></i>
                                </div>
                                <div class="activity-content">
                                    <p>Son galeri öğesi eklendi</p>
                                    <small>3 gün önce</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                
                <!-- Blog Yönetimi -->
                <section id="blog" class="admin-section">
                    <h2 class="section-title">Blog Yönetimi</h2>
                    
                    <?php if ($duzenle && $duzenle['tablo'] == 'blog'): ?>
                    <div class="edit-form">
                        <h3>Blog Yazısını Düzenle</h3>
                        <form method="post" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?= $duzenle['veri']['id'] ?>">
                            
                            <div class="form-group">
                                <label for="baslik">Başlık</label>
                                <input type="text" id="baslik" name="baslik" value="<?= htmlspecialchars($duzenle['veri']['baslik']) ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="kategori">Kategori</label>
                                <select id="kategori" name="kategori" required>
                                    <option value="kişisel" <?= $duzenle['veri']['kategori'] == 'kişisel' ? 'selected' : '' ?>>Kişisel</option>
                                    <option value="seyahat" <?= $duzenle['veri']['kategori'] == 'seyahat' ? 'selected' : '' ?>>Seyahat</option>
                                    <option value="kitap-film" <?= $duzenle['veri']['kategori'] == 'kitap-film' ? 'selected' : '' ?>>Kitap & Film</option>
                                    <option value="teknoloji" <?= $duzenle['veri']['kategori'] == 'teknoloji' ? 'selected' : '' ?>>Teknoloji</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="icerik">İçerik</label>
                                <textarea id="icerik" name="icerik" rows="10" required><?= htmlspecialchars($duzenle['veri']['icerik']) ?></textarea>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" name="blog_ekle" class="btn btn-primary">Güncelle</button>
                                <a href="admin.php" class="btn btn-secondary">İptal</a>
                            </div>
                        </form>
                    </div>
                    <?php else: ?>
                    <div class="add-form">
                        <h3>Yeni Blog Yazısı Ekle</h3>
                        <form method="post">
                            <div class="form-group">
                                <label for="baslik">Başlık</label>
                                <input type="text" id="baslik" name="baslik" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="kategori">Kategori</label>
                                <select id="kategori" name="kategori" required>
                                    <option value="kişisel">Kişisel</option>
                                    <option value="seyahat">Seyahat</option>
                                    <option value="kitap-film">Kitap & Film</option>
                                    <option value="teknoloji">Teknoloji</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="icerik">İçerik</label>
                                <textarea id="icerik" name="icerik" rows="10" required></textarea>
                            </div>
                            
                            <button type="submit" name="blog_ekle" class="btn btn-primary">Ekle</button>
                        </form>
                    </div>
                    
                    <div class="data-table">
                        <h3>Mevcut Blog Yazıları</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Başlık</th>
                                    <th>Kategori</th>
                                    <th>Tarih</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($blog = $blog_yazilari->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $blog['id'] ?></td>
                                    <td><?= htmlspecialchars($blog['baslik']) ?></td>
                                    <td><?= ucfirst($blog['kategori']) ?></td>
                                    <td><?= date('d.m.Y', strtotime($blog['yayin_tarihi'])) ?></td>
                                    <td class="actions">
                                        <a href="?duzenle=1&tablo=blog&id=<?= $blog['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                        <a href="?sil=1&tablo=blog&id=<?= $blog['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bu yazıyı silmek istediğinize emin misiniz?')"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </section>
                
                <!-- Galeri Yönetimi -->
                <section id="galeri" class="admin-section">
                    <h2 class="section-title">Galeri Yönetimi</h2>
                    
                    <?php if ($duzenle && $duzenle['tablo'] == 'galeri'): ?>
                    <div class="edit-form">
                        <h3>Galeri Öğesini Düzenle</h3>
                        <form method="post" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?= $duzenle['veri']['id'] ?>">
                            
                            <div class="form-group">
                                <label>Mevcut Resim</label>
                                <img src="<?= htmlspecialchars($duzenle['veri']['resim_yolu']) ?>" alt="Galeri resmi" style="max-width: 200px; display: block; margin-bottom: 10px;">
                            </div>
                            
                            <div class="form-group">
                                <label for="resim">Yeni Resim Seç</label>
                                <input type="file" id="resim" name="resim">
                            </div>
                            
                            <div class="form-group">
                                <label for="aciklama">Açıklama</label>
                                <input type="text" id="aciklama" name="aciklama" value="<?= htmlspecialchars($duzenle['veri']['aciklama']) ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="kategori">Kategori</label>
                                <select id="kategori" name="kategori" required>
                                    <option value="fotograf" <?= $duzenle['veri']['kategori'] == 'fotograf' ? 'selected' : '' ?>>Fotoğraf</option>
                                    <option value="hobi" <?= $duzenle['veri']['kategori'] == 'hobi' ? 'selected' : '' ?>>Hobi</option>
                                    <option value="video" <?= $duzenle['veri']['kategori'] == 'video' ? 'selected' : '' ?>>Video</option>
                                </select>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" name="galeri_ekle" class="btn btn-primary">Güncelle</button>
                                <a href="admin.php" class="btn btn-secondary">İptal</a>
                            </div>
                        </form>
                    </div>
                    <?php else: ?>
                    <div class="add-form">
                        <h3>Yeni Galeri Öğesi Ekle</h3>
                        <form method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="resim">Resim Seç</label>
                                <input type="file" id="resim" name="resim" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="aciklama">Açıklama</label>
                                <input type="text" id="aciklama" name="aciklama">
                            </div>
                            
                            <div class="form-group">
                                <label for="kategori">Kategori</label>
                                <select id="kategori" name="kategori" required>
                                    <option value="fotograf">Fotoğraf</option>
                                    <option value="hobi">Hobi</option>
                                    <option value="video">Video</option>
                                </select>
                            </div>
                            
                            <button type="submit" name="galeri_ekle" class="btn btn-primary">Ekle</button>
                        </form>
                    </div>
                    
                    <div class="data-table">
                        <h3>Galeri Öğeleri</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Resim</th>
                                    <th>Açıklama</th>
                                    <th>Kategori</th>
                                    <th>Tarih</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($galeri = $galeri_icerikleri->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $galeri['id'] ?></td>
                                    <td><img src="<?= htmlspecialchars($galeri['resim_yolu']) ?>" alt="Galeri resmi" style="max-width: 50px;"></td>
                                    <td><?= htmlspecialchars($galeri['aciklama']) ?></td>
                                    <td><?= ucfirst($galeri['kategori']) ?></td>
                                    <td><?= date('d.m.Y', strtotime($galeri['eklenme_tarihi'])) ?></td>
                                    <td class="actions">
                                        <a href="?duzenle=1&tablo=galeri&id=<?= $galeri['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                        <a href="?sil=1&tablo=galeri&id=<?= $galeri['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bu öğeyi silmek istediğinize emin misiniz?')"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </section>
                
                <!-- Hakkımda Yönetimi -->
                <section id="hakkimda" class="admin-section">
                    <h2 class="section-title">Hakkımda Yönetimi</h2>
                    
                    <form method="post">
                        <?php while ($hakkimda = $hakkimda_bilgileri->fetch_assoc()): ?>
                        <div class="form-group">
                            <label for="hakkimda_<?= $hakkimda['id'] ?>_baslik"><?= htmlspecialchars($hakkimda['baslik']) ?> Başlık</label>
                            <input type="text" id="hakkimda_<?= $hakkimda['id'] ?>_baslik" name="hakkimda[<?= $hakkimda['id'] ?>][baslik]" value="<?= htmlspecialchars($hakkimda['baslik']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="hakkimda_<?= $hakkimda['id'] ?>_icerik"><?= htmlspecialchars($hakkimda['baslik']) ?> İçerik</label>
                            <textarea id="hakkimda_<?= $hakkimda['id'] ?>_icerik" name="hakkimda[<?= $hakkimda['id'] ?>][icerik]" rows="5" required><?= htmlspecialchars($hakkimda['icerik']) ?></textarea>
                        </div>
                        <?php endwhile; ?>
                        
                        <button type="submit" name="hakkimda_guncelle" class="btn btn-primary">Güncelle</button>
                    </form>
                </section>
                
                <!-- SSS Yönetimi -->
                <section id="sss" class="admin-section">
                    <h2 class="section-title">SSS Yönetimi</h2>
                    
                    <?php if ($duzenle && $duzenle['tablo'] == 'sss'): ?>
                    <div class="edit-form">
                        <h3>SSS Düzenle</h3>
                        <form method="post">
                            <input type="hidden" name="id" value="<?= $duzenle['veri']['id'] ?>">
                            
                            <div class="form-group">
                                <label for="soru">Soru</label>
                                <input type="text" id="soru" name="soru" value="<?= htmlspecialchars($duzenle['veri']['soru']) ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="cevap">Cevap</label>
                                <textarea id="cevap" name="cevap" rows="5" required><?= htmlspecialchars($duzenle['veri']['cevap']) ?></textarea>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" name="sss_ekle" class="btn btn-primary">Güncelle</button>
                                <a href="admin.php" class="btn btn-secondary">İptal</a>
                            </div>
                        </form>
                    </div>
                    <?php else: ?>
                    <div class="add-form">
                        <h3>Yeni SSS Ekle</h3>
                        <form method="post">
                            <div class="form-group">
                                <label for="soru">Soru</label>
                                <input type="text" id="soru" name="soru" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="cevap">Cevap</label>
                                <textarea id="cevap" name="cevap" rows="5" required></textarea>
                            </div>
                            
                            <button type="submit" name="sss_ekle" class="btn btn-primary">Ekle</button>
                        </form>
                    </div>
                    
                    <div class="data-table">
                        <h3>Mevcut SSS Listesi</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Soru</th>
                                    <th>Cevap</th>
                                    <th>Tarih</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($sss = $sss_listesi->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $sss['id'] ?></td>
                                    <td><?= htmlspecialchars($sss['soru']) ?></td>
                                    <td><?= substr(htmlspecialchars($sss['cevap']), 0, 50) ?>...</td>
                                    <td><?= date('d.m.Y', strtotime($sss['eklenme_tarihi'])) ?></td>
                                    <td class="actions">
                                        <a href="?duzenle=1&tablo=sss&id=<?= $sss['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                        <a href="?sil=1&tablo=sss&id=<?= $sss['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bu SSS öğesini silmek istediğinize emin misiniz?')"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </section>
                
                <!-- İletişim Mesajları -->
                <section id="iletisim" class="admin-section">
                    <h2 class="section-title">İletişim Mesajları</h2>
                    
                    <div class="data-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Ad Soyad</th>
                                    <th>E-posta</th>
                                    <th>Konu</th>
                                    <th>Mesaj</th>
                                    <th>Tarih</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($mesaj = $iletisim_mesajlari->fetch_assoc()): ?>
                                <tr class="<?= $mesaj['okundu'] ? '' : 'unread' ?>">
                                    <td><?= $mesaj['id'] ?></td>
                                    <td><?= htmlspecialchars($mesaj['ad_soyad']) ?></td>
                                    <td><?= htmlspecialchars($mesaj['email']) ?></td>
                                    <td><?= htmlspecialchars($mesaj['konu']) ?></td>
                                    <td><?= substr(htmlspecialchars($mesaj['mesaj']), 0, 30) ?>...</td>
                                    <td><?= date('d.m.Y', strtotime($mesaj['gonderim_tarihi'])) ?></td>
                                    <td class="actions">
                                        <a href="#" class="btn btn-sm btn-primary" onclick="alert('<?= addslashes(htmlspecialchars($mesaj['mesaj'])) ?>')"><i class="fas fa-eye"></i></a>
                                        <a href="?sil=1&tablo=iletisim_mesajlari&id=<?= $mesaj['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bu mesajı silmek istediğinize emin misiniz?')"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </section>
                
                <!-- Kullanıcı Yönetimi -->
                <section id="kullanicilar" class="admin-section">
                    <h2 class="section-title">Kullanıcı Yönetimi</h2>
                    
                    <?php if ($duzenle && $duzenle['tablo'] == 'kullanicilar'): ?>
                    <div class="edit-form">
                        <h3>Kullanıcı Düzenle</h3>
                        <form method="post">
                            <input type="hidden" name="id" value="<?= $duzenle['veri']['id'] ?>">
                            
                            <div class="form-group">
                                <label for="kullanici_adi">Kullanıcı Adı</label>
                                <input type="text" id="kullanici_adi" name="kullanici_adi" value="<?= htmlspecialchars($duzenle['veri']['kullanici_adi']) ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="sifre">Yeni Şifre</label>
                                <input type="password" id="sifre" name="sifre" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="yetki_seviyesi">Yetki Seviyesi</label>
                                <select id="yetki_seviyesi" name="yetki_seviyesi" required>
                                    <option value="1" <?= $duzenle['veri']['yetki_seviyesi'] == 1 ? 'selected' : '' ?>>Standart Kullanıcı</option>
                                    <option value="10" <?= $duzenle['veri']['yetki_seviyesi'] == 10 ? 'selected' : '' ?>>Editör</option>
                                    <option value="99" <?= $duzenle['veri']['yetki_seviyesi'] == 99 ? 'selected' : '' ?>>Admin</option>
                                </select>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" name="kullanici_duzenle" class="btn btn-primary">Güncelle</button>
                                <a href="admin.php" class="btn btn-secondary">İptal</a>
                            </div>
                        </form>
                    </div>
                    <?php else: ?>
                    <div class="add-form">
                        <h3>Yeni Kullanıcı Ekle</h3>
                        <form method="post">
                            <div class="form-group">
                                <label for="kullanici_adi">Kullanıcı Adı</label>
                                <input type="text" id="kullanici_adi" name="kullanici_adi" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="sifre">Şifre</label>
                                <input type="password" id="sifre" name="sifre" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="yetki_seviyesi">Yetki Seviyesi</label>
                                <select id="yetki_seviyesi" name="yetki_seviyesi" required>
                                    <option value="1">Standart Kullanıcı</option>
                                    <option value="10">Editör</option>
                                    <option value="99">Admin</option>
                                </select>
                            </div>
                            
                            <button type="submit" name="kullanici_ekle" class="btn btn-primary">Ekle</button>
                        </form>
                    </div>
                    
                    <div class="data-table">
                        <h3>Kullanıcı Listesi</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Kullanıcı Adı</th>
                                    <th>Yetki Seviyesi</th>
                                    <th>Kayıt Tarihi</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($kullanici = $kullanicilar->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $kullanici['id'] ?></td>
                                    <td><?= htmlspecialchars($kullanici['kullanici_adi']) ?></td>
                                    <td>
                                        <?php 
                                        if ($kullanici['yetki_seviyesi'] == 99) echo 'Admin';
                                        elseif ($kullanici['yetki_seviyesi'] == 10) echo 'Editör';
                                        else echo 'Standart';
                                        ?>
                                    </td>
                                    <td><?= date('d.m.Y', strtotime($kullanici['olusturulma_tarihi'])) ?></td>
                                    <td class="actions">
                                        <a href="?duzenle=1&tablo=kullanicilar&id=<?= $kullanici['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                        <?php if ($kullanici['id'] != $_SESSION['admin_id']): ?>
                                        <a href="?sil=1&tablo=kullanicilar&id=<?= $kullanici['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bu kullanıcıyı silmek istediğinize emin misiniz?')"><i class="fas fa-trash"></i></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </section>
            </main>
            
            <footer class="admin-footer">
                <p>&copy; 2024 ibrahim - Tüm hakları saklıdır.</p>
            </footer>
        </div>
    </div>
    
    <script src="./js/admin.js"></script>
</body>
</html>
<?php
$db->close();
?>